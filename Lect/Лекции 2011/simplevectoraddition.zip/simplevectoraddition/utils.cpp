#include <windows.h>
#include <stdio.h>
#include <math.h>

#include "utils.h"

// defines
#define MIN_EPSILON_ERROR 1e-3f

void FillArray(float* pfData, int iSize)
{
  int i; 
  const float fScale = 1.0f / (float)RAND_MAX;
  for (i = 0; i < iSize; ++i) 
  {
    pfData[i] = fScale * rand();
  }
}

bool CompareDataAsFloatThreshold( const float* reference, const float* data, const unsigned int len, 
                                 const float epsilon, const float threshold) 
{
  if(epsilon < 0)
    return false;

  // If we set epsilon to be 0, let's set a minimum threshold
  float max_error = max( (float)epsilon, MIN_EPSILON_ERROR);
  int error_count = 0;
  bool result = true;

  for( unsigned int i = 0; i < len; ++i) {
    float diff = fabs((float)reference[i] - (float)data[i]);
    bool comp = (diff < max_error);
    result &= comp;

    if( ! comp) 
    {
      error_count++;
      if (error_count < 50) {
        printf("\n    ERROR(epsilon=%4.3f), i=%d, (ref)0x%02x / (data)0x%02x / (diff)%d\n", max_error, i, reference[i], data[i], (unsigned int)diff);
      }
    }
  }

  if (threshold == 0.0f) {
    if (error_count) {
      printf("\n    Total # of errors = %d\n", error_count);
    }
    return (error_count == 0) ? true : false;
  } else {

    if (error_count) {
      printf("\n    %.2f(%%) of bytes mismatched (count=%d)\n", (float)error_count*100/(float)len, error_count);
    }

    return ((len*threshold > error_count) ? true : false);
  }
}

//////////////////////////////////////////////////////////////////////////////
//! Loads a Program file and prepends the cPreamble to the code.
//!
//! @return the source string if succeeded, 0 otherwise
//! @param cFilename        program filename
//! @param cPreamble        code that is prepended to the loaded file, typically a set of #defines or a header
//! @param szFinalLength    returned length of the code string
//////////////////////////////////////////////////////////////////////////////
char* LoadProgSource(const char* cFilename, const char* cPreamble, size_t* szFinalLength)
{
  // locals 
  FILE* pFileStream = NULL;
  size_t szSourceLength;

  // open the OpenCL source code file
#ifdef _WIN32   // Windows version
  if(fopen_s(&pFileStream, cFilename, "rb") != 0) 
  {       
    return NULL;
  }
#else           // Linux version
  pFileStream = fopen(cFilename, "rb");
  if(pFileStream == 0) 
  {       
    return NULL;
  }
#endif

  size_t szPreambleLength = strlen(cPreamble);

  // get the length of the source code
  fseek(pFileStream, 0, SEEK_END); 
  szSourceLength = ftell(pFileStream);
  fseek(pFileStream, 0, SEEK_SET); 

  // allocate a buffer for the source code string and read it in
  char* cSourceString = (char *)malloc(szSourceLength + szPreambleLength + 1); 
  memcpy(cSourceString, cPreamble, szPreambleLength);
  if (fread((cSourceString) + szPreambleLength, szSourceLength, 1, pFileStream) != 1)
  {
    fclose(pFileStream);
    free(cSourceString);
    return 0;
  }

  // close the file and return the total length of the combined (preamble + source) string
  fclose(pFileStream);
  if(szFinalLength != 0)
  {
    *szFinalLength = szSourceLength + szPreambleLength;
  }
  cSourceString[szSourceLength + szPreambleLength] = '\0';

  return cSourceString;
}
