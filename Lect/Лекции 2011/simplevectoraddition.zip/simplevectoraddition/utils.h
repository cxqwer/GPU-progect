
void FillArray(float* pfData, int iSize);
bool CompareDataAsFloatThreshold( const float* reference, const float* data, const unsigned int len, 
                                 const float epsilon, const float threshold);
char* LoadProgSource(const char* cFilename, const char* cPreamble, size_t* szFinalLength);

