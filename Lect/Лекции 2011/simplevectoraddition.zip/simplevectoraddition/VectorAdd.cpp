/*
 * Copyright 1993-2010 NVIDIA Corporation.  All rights reserved.
 *
 * Please refer to the NVIDIA end user license agreement (EULA) associated
 * with this source code for terms and conditions that govern your use of
 * this software. Any use, reproduction, disclosure, or distribution of
 * this software and related documentation outside the terms of the EULA
 * is strictly prohibited.
 *
 */

// *********************************************************************
// oclVectorAdd Notes:  
//
// A simple OpenCL API demo application that implements 
// element by element vector addition between 2 float arrays. 
//
// Runs computations with OpenCL on the GPU device and then checks results 
// against basic host CPU/C++ computation.
//
// Uses some 'ocl' functions from oclUtils libraries for 
// compactness, but these are NOT required libs for OpenCL developement in general.
// *********************************************************************

// common SDK header for standard utilities and system libs 
#include <windows.h>
#include <math.h>
#include <assert.h>
//#include <rendercheckGL.h>

#include <stdio.h>
#include <CL/opencl.h>

#include "utils.h"

// Host buffers for demo
// *********************************************************************
void *srcA, *srcB, *dst;        // Host buffers for OpenCL test
void* Golden;                   // Host buffer for host golden processing cross check

// OpenCL Vars
cl_context cxGPUContext;        // OpenCL context
cl_command_queue cqCommandQueue;// OpenCL command que
cl_platform_id cpPlatform;      // OpenCL platform
cl_device_id cdDevice;          // OpenCL device
cl_program cpProgram;           // OpenCL program
cl_kernel ckKernel;             // OpenCL kernel
cl_mem cmDevSrcA;               // OpenCL device source buffer A
cl_mem cmDevSrcB;               // OpenCL device source buffer B 
cl_mem cmDevDst;                // OpenCL device destination buffer 
size_t szGlobalWorkSize;        // 1D var for Total # of work items
size_t szLocalWorkSize;		    // 1D var for # of work items in the work group	
size_t szParmDataBytes;			// Byte size of context information
size_t szKernelLength;			// Byte size of kernel code
cl_int ciErr1, ciErr2;			// Error code var
char* cPathAndName = NULL;      // var for full paths to data, src, etc.
char* cSourceCL = NULL;         // Buffer to hold source for compilation 

// demo config vars
int iNumElements = 11444992;	// Length of float arrays to process (odd # for illustration)

// Name of the file with the source code for the computation kernel
// *********************************************************************
const char* cSourceFile = "VectorAdd.cl";

// Forward Declarations
// *********************************************************************
void VectorAddHost(const float* pfData1, const float* pfData2, float* pfResult, int iNumElements);
void Cleanup (int iExitCode);
void InitMemorySizes();
void InitArrays();
void EnumeratePlatforms();
void EnumerateDevices();
void CreateContext();
void CreateCommandQueue();
void CreateMemObjects();
void CreateKernel();
void MakeGPUCalculations();
void CheckAgainstCPU();

// Main function 
// *********************************************************************
int main()
{
    InitMemorySizes();
    InitArrays();
    // --------------------------------------------------------
    EnumeratePlatforms();
    EnumerateDevices();
    CreateContext();
    CreateCommandQueue();
    // --------------------------------------------------------
    CreateMemObjects();
    CreateKernel();
    // --------------------------------------------------------
    MakeGPUCalculations();
    //--------------------------------------------------------
    CheckAgainstCPU();
    //--------------------------------------------------------
    // Cleanup and leave
    Cleanup (EXIT_SUCCESS);
}

void Cleanup (int iExitCode)
{
    // Cleanup allocated objects
    printf("Starting Cleanup...\n\n");
    if(cPathAndName)free(cPathAndName);
    if(cSourceCL)free(cSourceCL);
	if(ckKernel)clReleaseKernel(ckKernel);  
    if(cpProgram)clReleaseProgram(cpProgram);
    if(cqCommandQueue)clReleaseCommandQueue(cqCommandQueue);
    if(cxGPUContext)clReleaseContext(cxGPUContext);
    if(cmDevSrcA)clReleaseMemObject(cmDevSrcA);
    if(cmDevSrcB)clReleaseMemObject(cmDevSrcB);
    if(cmDevDst)clReleaseMemObject(cmDevDst);

    // Free host memory
    free(srcA); 
    free(srcB);
    free (dst);
    free(Golden);

    // finalize logs and leave
    {
        printf("oclVectorAdd.exe Exiting...\nPress <Enter> to Quit\n");
        getchar();
    }
    exit (iExitCode);
}

// "Golden" Host processing vector addition function for comparison purposes
// *********************************************************************
void VectorAddHost(const float* pfData1, const float* pfData2, float* pfResult, int iNumElements)
{
    int i;
    for (i = 0; i < iNumElements; i++) 
    {
        pfResult[i] = pfData1[i] + pfData2[i]; 
    }
}

void InitMemorySizes()
{
  // set and log Global and Local work size dimensions
  szLocalWorkSize = 256;
  assert(!(iNumElements % (int)szLocalWorkSize));
  szGlobalWorkSize = iNumElements; 
  printf("Global Work Size \t\t= %u\nLocal Work Size \t\t= %u\n# of Work Groups \t\t= %u\n\n", 
    szGlobalWorkSize, szLocalWorkSize, (szGlobalWorkSize % szLocalWorkSize + szGlobalWorkSize/szLocalWorkSize)); 
}

void InitArrays()
{
  // Allocate and initialize host arrays 
  printf( "Allocate and Init Host Mem...\n"); 
  srcA = (void *)malloc(sizeof(cl_float) * szGlobalWorkSize);
  srcB = (void *)malloc(sizeof(cl_float) * szGlobalWorkSize);
  dst = (void *)malloc(sizeof(cl_float) * szGlobalWorkSize);
  Golden = (void *)malloc(sizeof(cl_float) * iNumElements);
  FillArray((float*)srcA, iNumElements);
  FillArray((float*)srcB, iNumElements);
}

void EnumeratePlatforms()
{
  //Get an OpenCL platform
  ciErr1 = clGetPlatformIDs(1, &cpPlatform, NULL);
  printf("clGetPlatformID...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clGetPlatformID, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void EnumerateDevices()
{
  //Get the devices
  ciErr1 = clGetDeviceIDs(cpPlatform, CL_DEVICE_TYPE_GPU, 1, &cdDevice, NULL);
  printf("clGetDeviceIDs...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clGetDeviceIDs, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void CreateContext()
{
  //Create the context
  cxGPUContext = clCreateContext(0, 1, &cdDevice, NULL, NULL, &ciErr1);
  printf("clCreateContext...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clCreateContext, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void CreateCommandQueue()
{
  // Create a command-queue
  cqCommandQueue = clCreateCommandQueue(cxGPUContext, cdDevice, 0, &ciErr1);
  printf("clCreateCommandQueue...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clCreateCommandQueue, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void CreateMemObjects()
{
  // Allocate the OpenCL buffer memory objects for source and result on the device GMEM
  cmDevSrcA = clCreateBuffer(cxGPUContext, CL_MEM_READ_ONLY, sizeof(cl_float) * szGlobalWorkSize, NULL, &ciErr1);
  cmDevSrcB = clCreateBuffer(cxGPUContext, CL_MEM_READ_ONLY, sizeof(cl_float) * szGlobalWorkSize, NULL, &ciErr2);
  ciErr1 |= ciErr2;
  cmDevDst = clCreateBuffer(cxGPUContext, CL_MEM_WRITE_ONLY, sizeof(cl_float) * szGlobalWorkSize, NULL, &ciErr2);
  ciErr1 |= ciErr2;
  printf("clCreateBuffer...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clCreateBuffer, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void CreateKernel()
{
  // Read the OpenCL kernel in from source file
  printf("LoadProgSource (%s)...\n", cSourceFile); 
  cSourceCL = LoadProgSource(cSourceFile, "", &szKernelLength);

  // Create the program
  cpProgram = clCreateProgramWithSource(cxGPUContext, 1, (const char **)&cSourceCL, &szKernelLength, &ciErr1);
  printf("clCreateProgramWithSource...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clCreateProgramWithSource, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }

  // Build the program with 'mad' Optimization option
#ifdef MAC
  char* flags = "-cl-fast-relaxed-math -DMAC";
#else
  char* flags = "-cl-fast-relaxed-math";
#endif
  ciErr1 = clBuildProgram(cpProgram, 0, NULL, NULL, NULL, NULL);
  printf("clBuildProgram...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clBuildProgram, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }

  // Create the kernel
  ckKernel = clCreateKernel(cpProgram, "VectorAdd", &ciErr1);
  printf("clCreateKernel (VectorAdd)...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clCreateKernel, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }

  // Set the Argument values
  ciErr1 = clSetKernelArg(ckKernel, 0, sizeof(cl_mem), (void*)&cmDevSrcA);
  ciErr1 |= clSetKernelArg(ckKernel, 1, sizeof(cl_mem), (void*)&cmDevSrcB);
  ciErr1 |= clSetKernelArg(ckKernel, 2, sizeof(cl_mem), (void*)&cmDevDst);
  ciErr1 |= clSetKernelArg(ckKernel, 3, sizeof(cl_int), (void*)&iNumElements);
  printf("clSetKernelArg 0 - 3...\n\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clSetKernelArg, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void MakeGPUCalculations()
{
  // Start Core sequence... copy input data to GPU, compute, copy results back

  // Asynchronous write of data to GPU device
  ciErr1 = clEnqueueWriteBuffer(cqCommandQueue, cmDevSrcA, CL_FALSE, 0, sizeof(cl_float) * szGlobalWorkSize, srcA, 0, NULL, NULL);
  ciErr1 |= clEnqueueWriteBuffer(cqCommandQueue, cmDevSrcB, CL_FALSE, 0, sizeof(cl_float) * szGlobalWorkSize, srcB, 0, NULL, NULL);
  printf("clEnqueueWriteBuffer (SrcA and SrcB)...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clEnqueueWriteBuffer, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }

  // Launch kernel
  ciErr1 = clEnqueueNDRangeKernel(cqCommandQueue, ckKernel, 1, NULL, &szGlobalWorkSize, &szLocalWorkSize, 0, NULL, NULL);
  printf("clEnqueueNDRangeKernel (VectorAdd)...\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clEnqueueNDRangeKernel, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }

  // Synchronous/blocking read of results, and check accumulated errors
  ciErr1 = clEnqueueReadBuffer(cqCommandQueue, cmDevDst, CL_TRUE, 0, sizeof(cl_float) * szGlobalWorkSize, dst, 0, NULL, NULL);
  printf("clEnqueueReadBuffer (Dst)...\n\n"); 
  if (ciErr1 != CL_SUCCESS)
  {
    printf("Error in clEnqueueReadBuffer, Line %u in file %s !!!\n\n", __LINE__, __FILE__);
    Cleanup(EXIT_FAILURE);
  }
}

void CheckAgainstCPU()
{
  // Compute and compare results for golden-host and report errors and pass/fail
  printf("Comparing against Host/C++ computation...\n\n"); 
  VectorAddHost ((const float*)srcA, (const float*)srcB, (float*)Golden, iNumElements);
  bool bMatch = CompareDataAsFloatThreshold((const float*)Golden, (const float*)dst, (unsigned int)iNumElements, 0.0f, 0);
  printf("%s\n\n", bMatch ? "PASSED" : "FAILED");
}