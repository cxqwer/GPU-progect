#include "NBodySystemGPU.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

NBodySystemGPU::NBodySystemGPU(int bodies, float ** positionsCPU, float ** velocitiesCPU, bool & success)
    :bodies(bodies)
{
    cl_int error;
    
    // getting the first avaliable platform
    cl_platform_id clPlatformID;
    error = clGetPlatformIDs(1, &clPlatformID, NULL);
    error |= clGetPlatformInfo(clPlatformID, CL_PLATFORM_NAME, 0, NULL, NULL);
    platform = clPlatformID;
    
    // getting the first GPU device
    error |= clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &device, NULL);
    
    if (error != CL_SUCCESS)
    {
        success = false;
        return;
    }

    // creating the context
    context = clCreateContext(0, 1, &device, NULL, NULL, &error);

    if (error != CL_SUCCESS)
    {
        success = false;
        return;
    }

    // creating the command queue 
    queue = clCreateCommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, &error);

    if (error != CL_SUCCESS)
    {
        success = false;
        return;
    }

    // setting the local variables
    // (at the same time one of them supposed to be 0 and another to be 1)
    read = 0;
    write = 1;

    // reading the kernel
    FILE * f = NULL;
    char fileName[18] = "kernel.cl";
    
    f = fopen(fileName, "rb");
    if(f == NULL) 
    {   
        success = false;
        return;
    }

    // getting the length of the source code for the kernel
    fseek(f, 0, SEEK_END); 
    size_t codeLength = ftell(f);
    rewind(f); 

    char * code = (char *)malloc(codeLength + 1); 
    if (fread(code, codeLength, 1, f) != 1)
    {
        fclose(f);
        free(code);
        success = false;
        return;
    }

    // closing the file and 0-terminating the source code
    fclose(f);
    code[codeLength] = '\0';

    // creating the program
    program = clCreateProgramWithSource(context, 1, (const char **)&code, &codeLength, &error);
    
    if (error != CL_SUCCESS)
    {
        success = false;
        return;
    }

    // clearing the memory    
    free(code);

    // building the program
	error |= clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
    
    // creating the kernel
    kernel = clCreateKernel(program, "integrateBodies", &error);
  
    // setting the local size of the group the largest possible in order to load all computational units
    int numGroups;
    error |= clGetDeviceInfo(device, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(numGroups), &numGroups, NULL);
    localSize = bodies / numGroups;

    // allocating pinned buffers for veclocities and positions
    positionsCPUBuffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR, 4 * bodies * sizeof(float) , NULL, NULL);
    velocitiesCPUBuffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR, 4 * bodies * sizeof(float) , NULL, NULL);

    *positionsCPU = (float *)clEnqueueMapBuffer(queue, positionsCPUBuffer, CL_TRUE, CL_MAP_WRITE, 0, 4 * bodies * sizeof(float), 0, NULL, NULL, NULL);
    *velocitiesCPU = (float *)clEnqueueMapBuffer(queue, velocitiesCPUBuffer, CL_TRUE, CL_MAP_WRITE, 0, 4 * bodies * sizeof(float), 0, NULL, NULL, NULL);

    // initiliasing the bodies' postitions and velocities
    initBodies(*positionsCPU, *velocitiesCPU);
    
    // unmapping the pointers
    clEnqueueUnmapMemObject(queue, positionsCPUBuffer, *positionsCPU, 0, NULL, NULL);
    clEnqueueUnmapMemObject(queue, velocitiesCPUBuffer, *velocitiesCPU, 0, NULL, NULL);

    // we need to store the positions and velocities at the previous timestep,
    // so we allocate two arrays for positions and velocitites
    // 4 - because of the allignment
    positionsGPU[0] = clCreateBuffer(context, CL_MEM_READ_WRITE, 4 * bodies * sizeof(float) , NULL, NULL);
	positionsGPU[1] = clCreateBuffer(context, CL_MEM_READ_WRITE, 4 * bodies * sizeof(float), NULL, NULL);
    error |= clEnqueueWriteBuffer(queue, positionsGPU[0], CL_TRUE, 0, 4 * bodies * sizeof(float), *positionsCPU, 0, NULL, NULL);
    error |= clEnqueueWriteBuffer(queue, positionsGPU[1], CL_TRUE, 0, 4 * bodies * sizeof(float), *positionsCPU, 0, NULL, NULL); 

    velocitiesGPU[0] = clCreateBuffer(context, CL_MEM_READ_WRITE, 4 * bodies * sizeof(float), NULL, NULL);
	velocitiesGPU[1] = clCreateBuffer(context, CL_MEM_READ_WRITE, 4 * bodies * sizeof(float), NULL, NULL);
    error |= clEnqueueWriteBuffer(queue, velocitiesGPU[0], CL_TRUE, 0, 4 * bodies * sizeof(float), *velocitiesCPU, 0, NULL, NULL);
    error |= clEnqueueWriteBuffer(queue, velocitiesGPU[1], CL_TRUE, 0, 4 * bodies * sizeof(float), *velocitiesCPU, 0, NULL, NULL);
    
    if (error != CL_SUCCESS)
    {
        success = false;
        return;
    }
}

// initiliasing the bodies' positions and velocities
void NBodySystemGPU::initBodies(float * positionsCPU, float * velocitiesCPU)
{
    // points are placed randomly in the annulus
    float scale = 0.15f;
    float innerRad = 1.5f * scale, outerRad = 3.0f * scale;
    float phi = 0;

    // zeroing the memory
    memset(positionsCPU, 0, 4 * bodies * sizeof(float));
    memset(velocitiesCPU, 0, 4 * bodies * sizeof(float));

    // for the randomization
    srand((unsigned int)time(NULL));

    for (int i = 0; i < bodies; i++) 
    {
        //phi =  1.0 * i / bodies * 2 * CL_M_PI;
        // angle from -pi to pi
        phi = (rand() / (float) RAND_MAX * 2 - 1) * (float) CL_M_PI;
        positionsCPU[4 * i] =  cos(phi) * (innerRad + (outerRad - innerRad) * rand() / (float) RAND_MAX);
        positionsCPU[4 * i + 1] =  sin(phi) * (innerRad + (outerRad - innerRad) * rand() / (float) RAND_MAX);
        // no moving in z azis
        positionsCPU[4 * i + 2] =  0.0f;
        // mass is 10^11, because gravitational constant is ~ 10^-11
        positionsCPU[4 * i + 3] =  (float)pow(10.0, 11) * 1.0f; 
    }
    // velocities are zeros
}

// updating the bodies' positions and velocities    
void NBodySystemGPU::update(float dt, float * positionsCPU, float * velocititesCPU, bool & success)
{
    cl_int error = CL_SUCCESS;
    size_t global_work_size, local_work_size;
    success = true;
    
    if (localSize > bodies)
        localSize = bodies;
    local_work_size = localSize;
    global_work_size = bodies;
    
    // passing the arguments
    // we write the new positions and velocitites and read the previous ones
	error |= clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&positionsGPU[write]);
    error |= clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&velocitiesGPU[write]);
    error |= clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&positionsGPU[read]);
    error |= clSetKernelArg(kernel, 3, sizeof(cl_mem), (void *)&velocitiesGPU[read]);
    error |= clSetKernelArg(kernel, 4, sizeof(cl_float), (void *)&dt);
    error |= clSetKernelArg(kernel, 5, sizeof(cl_int), (void *)&bodies);
    error |= clSetKernelArg(kernel, 6, 4 * localSize * sizeof(cl_float), NULL);
    
    // just swap read and write in order not to copy the arrays
    int temp;
    temp = write;
    write = read;
    read = temp;

    // executing the kernel
    error |= clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &global_work_size, &local_work_size, 0, NULL, NULL);
    // synchronization 
    clFinish(queue);
    // reading the updated values (async)
    error |= clEnqueueReadBuffer(queue, positionsGPU[read], CL_FALSE, 0, 4 * bodies * sizeof(float), positionsCPU, 0, NULL, NULL);
    error |= clEnqueueReadBuffer(queue, velocitiesGPU[read], CL_FALSE, 0, 4 * bodies * sizeof(float), velocititesCPU, 0, NULL, NULL);
    
    if (error != CL_SUCCESS)
    {
        success = false;
    }
    return;
}


NBodySystemGPU::~NBodySystemGPU(void)
{
    // synchronization (if something has to be done) 
    clFinish(queue);
    // releasing all objects
    clReleaseMemObject(velocitiesGPU[0]);
    clReleaseMemObject(velocitiesGPU[1]);
    clReleaseMemObject(positionsGPU[0]);
    clReleaseMemObject(positionsGPU[1]);
    clReleaseMemObject(positionsCPUBuffer);
    clReleaseMemObject(velocitiesCPUBuffer);
    clReleaseKernel(kernel);
    clReleaseProgram(program);
    clReleaseCommandQueue(queue);
    clReleaseContext(context);
}
