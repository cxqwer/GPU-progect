#pragma once

#include <CL\opencl.h>

// class for working the bodies system
class NBodySystemGPU
{
public:
    // number of bodies
    int bodies;
    NBodySystemGPU(int bodies, float ** positionsCPU, float ** velocitiesCPU, bool & success);
    // updating the bodies' positions and velocities
    void update (float dt, float * positionsCPU, float * velocitiesCPU, bool & success);
    ~NBodySystemGPU(void);
private:
    // OpenCL variables
    cl_platform_id platform;          
    cl_context context;               
    cl_command_queue queue;    
    cl_device_id device;     
    cl_kernel kernel;
    cl_program program;
    // GPU arrays for the bodies
    cl_mem positionsGPU[2];
    cl_mem velocitiesGPU[2];
    cl_mem positionsCPUBuffer;
    cl_mem velocitiesCPUBuffer;

    // size of the work group
    int localSize;
    // local variables (used to switch between the GPU arrays)
    int write;
    int read;
    // initiliasing the bodies' positions and velocities
    void initBodies(float * positionsCPU, float * velocitiesCPU);

};

