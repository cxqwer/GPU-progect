////////////////////////////////////////////////////////////////////////////////
// Filename: modelclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "modelclass.h"

ModelClass::ModelClass(int bodies)
{
	m_vertexBuffer = 0;
	m_indexBuffer = 0;

	m_positions = 0;
	m_velocities = 0;
	m_bodySystem = 0;

	m_bodies = bodies;
}


ModelClass::ModelClass(const ModelClass& other)
{
}


ModelClass::~ModelClass()
{
}


bool ModelClass::Initialize(ID3D10Device* device)
{
	bool result;

	m_positions = new float[COORD_DIM * m_bodies];
	m_velocities = new float[VEL_DIM * m_bodies];

	m_bodySystem = new class FallBodyClass(m_bodies, &m_positions, &m_velocities, result);
	
	if (!result) {
		return false;
	}
	// Initialize the vertex and index buffer that hold the geometry for the triangle.
	result = InitializeBuffers(device);
	if(!result)
	{
		return false;
	}

	return true;
}


void ModelClass::Shutdown()
{
	// Release the vertex and index buffers.
	ShutdownBuffers();
	
	if (m_bodySystem) {
		delete m_bodySystem;
	}
	return;
}


void ModelClass::Render(ID3D10Device* device)
{
	//update bodies' positions
	bool result;
	m_bodySystem->update(0.01f, m_positions, m_velocities, result);
	
	//InitializeBuffers(device);
	D3D10_MAPPED_TEXTURE3D resource;
	ZeroMemory(&resource, sizeof(D3D10_MAPPED_TEXTURE3D));
	result = m_vertexBuffer->Map(D3D10_MAP_WRITE_DISCARD, 0, &resource.pData);
	memcpy(resource.pData, m_positions , COORD_DIM * m_bodies * sizeof(float));
	m_vertexBuffer->Unmap();
	// Put the vertex and index buffers on the graphics pipeline to prepare them for drawing.*/
	RenderBuffers(device);
	return;
}


int ModelClass::GetIndexCount()
{
	//return m_indexCount;
	return m_bodies;
}

float * ModelClass::GetPositions()
{
	return m_positions;
}


bool ModelClass::InitializeBuffers(ID3D10Device* device)
{
	unsigned long* indices;
	D3D10_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
    D3D10_SUBRESOURCE_DATA vertexData, indexData;
	HRESULT result;

	// Create the index array.
	indices = new unsigned long[m_bodies];
	if(!indices)
	{
		return false;
	}

	// Load the vertex array with data.
	for (int i = 0; i < m_bodies; ++i) {
		indices[i] = i;
	}

	// Set up the description of the vertex buffer.
	ZeroMemory(&vertexBufferDesc, sizeof(vertexBufferDesc));
	vertexBufferDesc.Usage = D3D10_USAGE_DYNAMIC;
	vertexBufferDesc.ByteWidth = sizeof(ModelVertex) * m_bodies;
    vertexBufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
	vertexBufferDesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    vertexBufferDesc.MiscFlags = 0;

	// Give the subresource structure a pointer to the vertex data.
	ZeroMemory(&vertexData, sizeof(vertexData));
	vertexData.pSysMem = m_positions;
	vertexData.SysMemPitch = 0;
	vertexData.SysMemSlicePitch = 0;

	// Now finally create the vertex buffer.
    result = device->CreateBuffer(&vertexBufferDesc, &vertexData, &m_vertexBuffer);
	if(FAILED(result))
	{
		return false;
	}

	// Set up the description of the index buffer.
	ZeroMemory(&indexBufferDesc, sizeof(indexBufferDesc));
    indexBufferDesc.Usage = D3D10_USAGE_DYNAMIC;
	indexBufferDesc.ByteWidth = sizeof(unsigned long) * m_bodies;
    indexBufferDesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
    indexBufferDesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    indexBufferDesc.MiscFlags = 0;

	// Give the subresource structure a pointer to the index data.
    indexData.pSysMem = indices;

	// Create the index buffer.
	result = device->CreateBuffer(&indexBufferDesc, &indexData, &m_indexBuffer);
	if(FAILED(result))
	{
		return false;
	}

	// Release the arrays now that the vertex and index buffers have been created and loaded.

	delete [] indices;
	indices = 0;

	return true;
}


void ModelClass::ShutdownBuffers()
{
	// Release the index buffer.
	if(m_indexBuffer)
	{
		m_indexBuffer->Release();
		m_indexBuffer = 0;
	}

	// Release the vertex buffer.
	if(m_vertexBuffer)
	{
		m_vertexBuffer->Release();
		m_vertexBuffer = 0;
	}

	return;
}


void ModelClass::RenderBuffers(ID3D10Device* device)
{
	unsigned int stride;
	unsigned int offset;

	// Set vertex buffer stride and offset.
	stride = sizeof(ModelVertex);
	offset = 0;
    
	// Set the vertex buffer to active in the input assembler so it can be rendered.
	device->IASetVertexBuffers(0, 1, &m_vertexBuffer, &stride, &offset);

    // Set the index buffer to active in the input assembler so it can be rendered.
    device->IASetIndexBuffer(m_indexBuffer, DXGI_FORMAT_R32_UINT, 0);
	
    // Set the type of primitive that should be rendered from this vertex buffer, in this case triangles.
	device->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);

	return;
}