# OpenCL-learning-VS2012
My learning projects for OpenCL in Visual Studio 2012

Configuration in Visual Studio : https://medium.com/@pratikone/opencl-on-visual-studio-configuration-tutorial-for-the-confused-3ec1c2b5f0ca#.sr5v6xukd
